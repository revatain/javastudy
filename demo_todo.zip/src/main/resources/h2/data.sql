INSERT INTO `todo` (`content`, `done_yn`, `delete_yn`, `create_date`) VALUES
    ('일어나기', 'Y', 'N', now()),
    ('양치하기', 'Y', 'N', now()),
    ('샤워하기', 'N', 'N', now()),
    ('출근하기', 'N', 'N', now()),
    ('퇴근하기', 'N', 'N', now());