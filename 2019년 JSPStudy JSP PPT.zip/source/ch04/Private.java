package ch04;

class OutSider1{
	private String s="OutSider";
}

public class Private {
	public static void main(String[] args) {
		OutSider1 o = new OutSider1();
		System.out.println(o.s);
	}
}