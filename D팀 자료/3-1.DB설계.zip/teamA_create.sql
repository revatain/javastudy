/*회원 테이블
==================================*/
CREATE TABLE member(
mb_id CHAR(8) PRIMARY KEY, /*회원 아이디*/
mb_pwd CHAR(10) NOT NULL,  /*회원 패스워드*/
mb_username CHAR(10) NOT NULL /*회원 이용자명*/
)




/*일정 테이블
==================================*/
CREATE TABLE sched(
/*SCHEDULE은 예약어이므로, 
축약어인 sched로 대체했습니다.*/


/*[------------일정 관련 필수값--------------]*/

sc_id CHAR(8) PRIMARY KEY NOT NULL ,
/*일정마다 부여될 고유 식별값*/

sc_date DATE NOT NULL,
/*일정 날짜*/

sc_title CHAR(30) NOT NULL 
/*일정 제목, 달력에 표시됨*/




/*[------------일정 관련 선택값--------------]*/

sc_content CHAR(200),
/*일정 세부내용*/

sc_isdone BOOLEAN, 
/*일정 수행여부*/

sc_privacy CHAR(10),
/*일정 공개설정 : 개인용, 전체공개, 제한적 공개*/

sc_priority INT(1),  
/*일정 중요도 : 0, 1, 2 순으로 각각 "중요도 없음", "중요", "매우 중요"*/
);



/*일정 테이블에서 활용 가능할 SELECT문 :
특정 날짜 이전, 이후의 메모만 조회하는 SQL문.
SELECT * FROM sched WHERE sc_date BEETWEN AND(날짜 대소비교)
*/


/* 할일 테이블 : 매일 수행하는 반복성 업무
===========================*/
CREATE TABLE todo(

td_1 CHAR(30),
td_2 CHAR(30),
td_3 CHAR(30),
/*속성의 갯수는 테이블의 최대 크기만큼, 또는 항목 갯수에 따라 유동적으로*/

);




/* 댓글 테이블 : 일정마다 남길 수있는 간단한 코멘트
===========================*/
CREATE TABLE reply(
/*comment가 예약어이므로, 
유의어인 reply로 대체했습니다.*/

sc_id CHAR(8) PRIMARY KEY NOT NULL,
/* 해당하는 일정과 일치해야 할 키 값. */

rp_1 CHAR(30),
rp_2 CHAR(30),
rp_3 CHAR(30),
/*속성의 갯수는 테이블의 최대 크기만큼, 또는 항목 갯수에 따라 유동적으로*/

);


/* 댓글 테이블에서 활용 가능할 SELECT문 :
SELECT * FROM WHERE sc_id = sched.sc_id
*/