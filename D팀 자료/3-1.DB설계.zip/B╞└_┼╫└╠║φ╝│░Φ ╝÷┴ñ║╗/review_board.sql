CREATE TABLE review_board
(
    `num`   INT            NOT NULL    AUTO_INCREMENT COMMENT 'num', 
    `user_id`    VARCHAR(10)   NOT NULL        COMMENT 'id', 
    `user_name`  VARCHAR(10)    NOT NULL        COMMENT 'writer', 
    `제목`    VARCHAR(80)   NOT NULL        COMMENT 'title', 
    `내용`    TEXT           NOT NULL        COMMENT 'content', 
    `날짜`    DATE          NOT NULL        COMMENT 'date', 
    `비밀번호`  INT    NULL        COMMENT 'pwd', /*게시글 삭제 시 필요한 비밀번호 4자리, NULL 값 허용*/
     PRIMARY KEY (num)
);

ALTER TABLE Board2 COMMENT 'review';mybook