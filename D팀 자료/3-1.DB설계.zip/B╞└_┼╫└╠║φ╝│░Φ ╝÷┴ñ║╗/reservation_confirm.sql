/*예약내역 확인 테이블 */

CREATE TABLE reservation_confirm(
user_id VARCHAR(10) PRIMARY KEY, /*예약자  아이디 */
user_name VARCHAR(10) NOT NULL, /* 예약자 이름*/
r_room CHAR(10) NOT NULL, /*예약 룸*/
r_date DATE NOT NULL,  /*이용날짜 */
r_capacity INT NOT NULL, /* 이용인원*/
r_number INT PRIMARY KEY /*예약번호 16자리, payment 테이블과 연결*/
)
