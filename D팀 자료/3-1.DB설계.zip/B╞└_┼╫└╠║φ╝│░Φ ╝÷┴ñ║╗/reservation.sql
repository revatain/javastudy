/*예약 테이블 */

CREATE TABLE reservation(
user_id VARCHAR(10) PRIMARY KEY, /*예약자  아이디 */
user_name VARCHAR(10) NOT NULL, /* 예약자 이름*/
r_room CHAR(10) NOT NULL, /*예약 룸*/
r_date DATE NOT NULL,  /*이용날짜 */
r_capacity INT NOT NULL /* 이용인원*/
r_status CHAR(10) NOT NULL, /*예약상태 : 예약가능, 예약완료 */

/*결제금액은 안 들어가도 되는지?*/
)

