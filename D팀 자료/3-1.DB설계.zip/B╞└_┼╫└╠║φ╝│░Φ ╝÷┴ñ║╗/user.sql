/*--B팀 데이터 테이블 --*/
/*-- 1. 회원 --*/

CREATE TABLE user (
	user_id VARCHAR(10) PRIMARY KEY, /*--사용자 아이디--*/
	user_password CHAR(10) NOT NULL, /*--사용자 비밀번호--*/
	user_name VARCHAR(10) NOT NULL, /*--사용자 이름(예약자이름)--*/
	user_email CHAR(30) NOT NULL, /*--사용자 이메일 (추후 예약 및 결제내역 발송용)--*/
	user_phone INT(20) NOT NULL, /*--사용자 핸드폰번호--*/ 
	user_birthday DATE NOT NULL, /*--사용자 생년월일--*/
	user_gender CHAR(2) NOT NULL /*--사용자 성별--*/
)

/*추후 추가될 수 있는 정보 생각해볼것*/