USE mybook;

CREATE TABLE wc(
	num INT PRIMARY KEY AUTO_INCREMENT,
	region CHAR(10) NOT NULL,
	weather CHAR(5) NOT NULL,
	tem_mid INT NOT NULL/*temperature_middle 평균 기온*/
)

INSERT wc VALUES (NULL ,'경기도','맑음',15);
INSERT wc VALUES (NULL ,'충청북도','흐림',16);
INSERT wc VALUES (NULL ,'충청남도','비',17);
INSERT wc VALUES (NULL ,'전라북도','눈',18);
INSERT wc VALUES (NULL ,'전라남도','태풍',19);
INSERT wc VALUES (NULL ,'경상북도','맑음',20);
INSERT wc VALUES (NULL ,'경상남도','흐림',21);
INSERT wc VALUES (NULL ,'제주도','비',22);
INSERT wc VALUES (NULL ,'부산','눈',23);
INSERT wc VALUES (NULL ,'서울','태풍',24);

SELECT * FROM wc;

CREATE TABLE wc_region(
	num INT PRIMARY KEY AUTO_INCREMENT,
	region CHAR(10) NOT NULL,
	reg_det CHAR(10) NOT NULL, /*reg_details 세부 지역*/
	weather CHAR(5) NOT NULL,
	tem_mid INT NOT NULL/*temperature_middle 평균 기온*/
)

INSERT wc_region VALUES (NULL ,'부산','진구','맑음',15);
INSERT wc_region VALUES (NULL ,'부산','해운대구','흐림',14);
INSERT wc_region VALUES (NULL ,'부산','강서구','비',13);
INSERT wc_region VALUES (NULL ,'부산','수영구','눈',12);
INSERT wc_region VALUES (NULL ,'부산','연제구','태풍',11);

SELECT * FROM wc_region; 