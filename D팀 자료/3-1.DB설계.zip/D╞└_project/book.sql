CREATE TABLE `book` (
  `number` INT AUTO_INCREMENT PRIMARY KEY,
  `writer` CHAR(20) NOT NULL, 
  `name` CHAR(50) NOT NULL,
  `publisher` CHAR (50) NOT NULL,
  `genre` CHAR (30) NOT NULL,
  `borrow` CHAR (10) NOT NULL,
  `return` CHAR (10) NOT NULL,
  `borrow_Who` CHAR (10) NOT NULL,
  `return_Who` CHAR (10) NOT NULL,
  `borrow_Time` DATE NOT NULL,
  `return_Time` DATE NOT NULL
);
