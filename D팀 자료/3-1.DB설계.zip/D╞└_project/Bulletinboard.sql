CREATE TABLE BulletinBoard(
order_number INT PRIMARY KEY,
title_name CHAR(10) NOT NULL,
writer_name CHAR(10) NOT NULL,
make_date DATE NOT NULL,
hits_data INT NOT NULL,
attachment_data CHAR(10)
)

INSERT BulletinBoard VALUES(1, '신간안내', '관리자', '2022-01-20', '3', '1'); 
INSERT BulletinBoard VALUES(2, '대여기간안내', '관리자', '2021-01-13', '2', '1');
INSERT BulletinBoard VALUES(3, '코로나감염증예방수칙', '관리자', '2020-01-10', '0', '1');

SELECT * FROM bulletinboard; 