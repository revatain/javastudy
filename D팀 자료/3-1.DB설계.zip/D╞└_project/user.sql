CREATE TABLE `user` (
  `id` CHAR(20) PRIMARY KEY,
  `pw` CHAR(20) NOT NULL,
  `name` CHAR(5) NOT NULL,
  `sex` CHAR(5) NOT NULL,
  `birthday` CHAR(6) NOT NULL,
  `email` CHAR(30) NOT NULL,
  `homemail` CHAR(5) NOT NULL,
  `address` CHAR(60) NOT NULL,
  `job` CHAR(20) NOT NULL,
  `borrow` CHAR (10) NOT NULL,
  `return` CHAR (10) NOT NULL
);
