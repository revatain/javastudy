public class App {
    public static void main(String[] args) throws Exception {

        // 자바 변수 스코프는 자스 let const와 같다
        // (지역)변수는 블록 단위로 작동
        // 자바는 정적 타입 언어
        // 자바스크립트는 동적 타입 언어
        // String str = "data";
        // System.out.println(str);
        // str = 1;

        // Temp temp = new Temp();

    }
}
