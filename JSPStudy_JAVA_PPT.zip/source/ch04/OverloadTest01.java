package ch04;

public class OverloadTest01 {

	public static void main(String[] args) {
		System.out.println("����");
		System.out.println(10);
		System.out.println(5.95);
		System.out.println(true);
	}
}