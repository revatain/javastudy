package ch04;

public class ClassTest01 {
	String hand;
	String leg;
	String head;
	String eyes;
	String runSpeed;
	String hasWeapon;
	String height;
	public static void main(String[] args) {
	//	hand = '1';
	}
}