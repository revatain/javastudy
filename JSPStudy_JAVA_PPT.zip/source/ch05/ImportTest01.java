package ch05;
 
import ch04.MethodTest02; //��й�ȣ Ǯ��

public class ImportTest01 {

	public static void main(String[] args) {
		MethodTest02 mt = new MethodTest02();
		mt.morningTest();
	}
}