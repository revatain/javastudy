package ch06;

public class StaticTip01 {

	public static void main(String[] args) {
		//static int num; 

	}
	
	void notMethod(){
		//static int num; 
	}

}
