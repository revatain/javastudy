package ch06;

public class StaticTest02 {
	
	public static void main(String[] args) {
		System.out.println(StaticTest01.num);
	}
}