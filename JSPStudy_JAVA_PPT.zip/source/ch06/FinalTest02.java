package ch06;

final public class FinalTest02 {
	
}