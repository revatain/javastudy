package ch06;

public class FinalTest03 /*extends FinalTest02*/{

}