package ch06;

public class StaticMethod01 {
	
	public static void main(String[] args) {
		stMethod();
	}

	static void stMethod(){
		System.out.println("static �޼ҵ� ����");
	}
}