package ch06;

public class FinalTest05 extends FinalTest04{

	public static void main(String args[]) {
		FinalTest04 finalTest = new FinalTest04();
		finalTest.finalTest();
	}

	/* ����
	@Override
	public void finalTest() {
		// TODO Auto-generated method stub
		super.finalTest();
	}
	*/
}